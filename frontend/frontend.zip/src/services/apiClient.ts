import axios from "axios";

const API_BASE_URL =
  import.meta.env.VITE_API_URL ??
  "http://localhost:8000/api";

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 0,
  headers: {
    Accept: "application/json",
  },
});